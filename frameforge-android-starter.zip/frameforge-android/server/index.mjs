import express from "express";
import cors from "cors";
import "dotenv/config";

const app = express();
const port = Number(process.env.PORT || 8787);
const allowed = (process.env.ALLOWED_ORIGIN || "http://localhost:5173").split(",").map(s => s.trim());
app.use(cors({ origin(origin, cb) {
  if (!origin || allowed.includes(origin)) return cb(null, true);
  cb(new Error("Origin not allowed"));
}}));
app.use(express.json({ limit: "30mb" }));

app.get("/health", (_req, res) => res.json({ ok: true, service: "frameforge-proxy" }));

// Stateless proxy: the user's key is forwarded for this request only.
// Do not add request-body/header logging or persist credentials.
app.all("/muapi/*", async (req, res) => {
  const key = req.header("x-muapi-key");
  if (!key) return res.status(401).json({ error: "Add your Muapi API key in Settings." });
  const path = req.params[0] || "";
  if (!/^api\\/v1\\//.test(path) && !/^api\\/v1\\/predictions\\//.test(path)) {
    return res.status(400).json({ error: "Unsupported provider path." });
  }
  try {
    const upstream = await fetch(`https://api.muapi.ai/${path}`, {
      method: req.method,
      headers: { "x-api-key": key, "Content-Type": "application/json" },
      ...(req.method === "GET" || req.method === "HEAD" ? {} : { body: JSON.stringify(req.body ?? {}) })
    });
    const body = await upstream.text();
    res.status(upstream.status).type(upstream.headers.get("content-type") || "application/json").send(body);
  } catch {
    res.status(502).json({ error: "Muapi could not be reached. Check the server connection and try again." });
  }
});

app.listen(port, "0.0.0.0", () => console.log(`FRAMEFORGE proxy listening on ${port}`));
