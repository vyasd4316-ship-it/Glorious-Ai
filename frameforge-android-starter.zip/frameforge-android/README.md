# FRAMEFORGE

An open-source, local-first generative media studio starter with Image, Video, Lip Sync and Cinema workspaces. React + Vite PWA, Capacitor-ready Android wrapper, and a stateless Muapi proxy.

## Current scope

- Responsive dark studio UI for desktop and Android browsers.
- Four studios with cinema controls (shot, focal length, aperture, movement).
- Video mode reacts to an added image and switches to image-to-video.
- Upload library and generation metadata are stored in IndexedDB on the device.
- Muapi model catalog refresh, async submit/poll adapter, status history and original result link.
- API key is stored in browser localStorage on the device and forwarded only for an individual proxy request. The proxy does not persist it.
- Model catalog schemas vary; this starter intentionally refuses to invent endpoints or claim unsupported model fields. Review model-specific schemas before production use.

## Run locally

```bash
npm install
cp .env.example .env
npm run dev
```

In another terminal:

```bash
npm run server
```

Open http://localhost:5173. Add your own Muapi API key under Settings. Use a sandbox key while developing.

## Android

Install Node.js and Android Studio, then:

```bash
npm install
npx cap add android
npm run android:sync
npm run android:open
```

In Android Studio, select an emulator or connected device and run the app. To build an APK, use Android Studio's Build > Build Bundle(s) / APK(s). This repository is Capacitor-ready; it does not include a prebuilt APK.

For an Android-first browser install, open the deployed HTTPS site in Chrome and choose Install app / Add to Home screen.

## Self-host

The included Express proxy forwards requests to `https://api.muapi.ai` and is stateless with respect to user credentials.

```bash
docker compose up --build
```

For a real deployment, serve the Vite `dist` output from a static host or add a static web server to the compose stack, and set `ALLOWED_ORIGIN` to the exact deployed origin. Put TLS in front of the service. Do not expose the proxy publicly without rate limiting and abuse protection.

## Muapi API flow

- Catalog: `GET https://api.muapi.ai/api/v1/models`
- Submit: `POST https://api.muapi.ai/api/v1/{model-endpoint}` with `x-api-key`
- Poll: `GET https://api.muapi.ai/api/v1/predictions/{request_id}/result`

The live catalog and model playground define each model's actual endpoint and required request schema. This starter includes a small fallback list for UI preview; only entries with a verified endpoint can submit. Adapt `src/App.tsx`'s model normalizer and payload builder to the exact model schema you choose. Multi-image support is represented in the model manifest and must be populated from verified model metadata.

## Security and privacy notes

- API key storage uses browser localStorage for convenience. This is local to the browser profile but is not a hardware-backed secure vault; anyone with access to the unlocked browser profile or same-origin script execution may be able to read it. Use a dedicated browser profile/device and remove the key when finished.
- The key is sent to the configured self-hosted proxy for each request. The proxy forwards it to Muapi and does not write it to disk. The proxy operator can see credentials in transit; self-host only on a server you control and use HTTPS.
- Add request size limits, rate limiting, origin controls, authentication, and log redaction before exposing a public deployment.
- Upload previews are read locally; files are sent to the provider only after a generation request is submitted.
- Lip Sync includes a permission confirmation. Use only media you own or have explicit permission to use.

## Extend the model catalog

Add model metadata to the normalized catalog with:
- `id`, `name`, `endpoint`, `category`, `quality`
- `input_types` such as `text`, `image`, `audio`, `video`
- `supports_multi_image` only when the model's current schema confirms it

Then add a schema-driven form/payload adapter for the model. Never assume all endpoints accept the same field names.

## License

MIT
