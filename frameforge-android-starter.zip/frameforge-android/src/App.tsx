import { useEffect, useMemo, useRef, useState } from "react";
import { Image, Video, AudioLines, Clapperboard, Settings, History, Upload, Sparkles, Download, Plus, X, ChevronDown, KeyRound, RefreshCw, CheckCircle2, AlertCircle, Menu, Film, SlidersHorizontal, Clock3, Trash2 } from "lucide-react";
import { openDB } from "idb";

type Studio = "Image" | "Video" | "Lip Sync" | "Cinema";
type Model = { id: string; name: string; endpoint?: string; category?: string; quality?: string; supports_multi_image?: boolean; input_types?: string[]; [k:string]: any };
type Asset = { id: string; name: string; type: string; dataUrl: string; created: number };
type Job = { id: string; studio: Studio; prompt: string; model: string; status: string; output?: string; created: number; requestId?: string };

const icons = { Image, Video, "Lip Sync": AudioLines, Cinema: Clapperboard };
const API = (import.meta as any).env.VITE_PROXY_URL || "http://localhost:8787";
const starterModels: Model[] = [
  { id:"flux-dev-image", name:"FLUX Dev", endpoint:"flux-dev-image", category:"image", quality:"Balanced", input_types:["text"] },
  { id:"flux-kontext-dev-t2i", name:"FLUX Kontext", endpoint:"flux-kontext-dev-t2i", category:"image", quality:"Balanced", input_types:["text","image"] },
  { id:"kling", name:"Kling Video", endpoint:"", category:"video", quality:"Pro", input_types:["text","image"] },
  { id:"lipsync", name:"AI Avatar & Lipsync", endpoint:"", category:"lipsync", quality:"Studio", input_types:["image","audio"] }
];

async function db() {
  return openDB("frameforge-local", 1, { upgrade(d) {
    if (!d.objectStoreNames.contains("assets")) d.createObjectStore("assets", { keyPath:"id" });
    if (!d.objectStoreNames.contains("jobs")) d.createObjectStore("jobs", { keyPath:"id" });
  }});
}
const uid = () => crypto.randomUUID();

export default function App() {
  const [studio, setStudio] = useState<Studio>("Image");
  const [prompt, setPrompt] = useState("");
  const [models, setModels] = useState<Model[]>(starterModels);
  const [modelId, setModelId] = useState("flux-dev-image");
  const [assets, setAssets] = useState<Asset[]>([]);
  const [jobs, setJobs] = useState<Job[]>([]);
  const [apiKey, setApiKey] = useState(localStorage.getItem("ff_muapi_key") || "");
  const [showKey, setShowKey] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState("");
  const [menuOpen, setMenuOpen] = useState(false);
  const [aspect, setAspect] = useState("16:9");
  const [duration, setDuration] = useState("5");
  const [lens, setLens] = useState("35mm");
  const [aperture, setAperture] = useState("f/2.8");
  const [cameraMove, setCameraMove] = useState("Slow dolly");
  const [shot, setShot] = useState("Medium close-up");
  const [consent, setConsent] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const selected = models.find(m => m.id === modelId) || models[0];
  const hasImage = assets.some(a => a.type.startsWith("image/"));
  const uploadMode = studio === "Video" && hasImage;
  const multiImage = Boolean(selected?.supports_multi_image);
  const filteredModels = useMemo(() => models.filter(m => {
    const c = (m.category || "").toLowerCase();
    return studio === "Image" ? c.includes("image") : studio === "Video" || studio === "Cinema" ? c.includes("video") : c.includes("lip") || c.includes("audio");
  }), [models, studio]);

  useEffect(() => { (async () => {
    const d = await db();
    setAssets(await d.getAll("assets"));
    setJobs((await d.getAll("jobs")).sort((a,b)=>b.created-a.created));
  })(); }, []);
  useEffect(() => { setPrompt(""); setConsent(false); }, [studio]);
  useEffect(() => {
    const c = selected?.category?.toLowerCase() || "";
    const compatible = models.filter(m => studio === "Image" ? c.includes("image") : studio === "Lip Sync" ? (m.category||"").toLowerCase().includes("lip") : (m.category||"").toLowerCase().includes("video"));
    if (compatible.length && !compatible.some(m => m.id === modelId)) setModelId(compatible[0].id);
  }, [studio, models]);

  async function refreshModels() {
    try {
      const r = await fetch(`${API}/muapi/api/v1/models`, { headers: { "x-muapi-key": apiKey } });
      if (!r.ok) throw new Error("Could not load live model catalog.");
      const data = await r.json();
      const list = Array.isArray(data) ? data : data.models || data.data || [];
      if (!list.length) throw new Error("The catalog response had no model entries.");
      setModels(list.map((m:any) => ({ ...m, id: m.id || m.slug || m.endpoint, name: m.name || m.id || m.slug, category: m.category || m.task || "other", endpoint: m.endpoint || m.api_endpoint })));
      setNotice("Live model catalog refreshed.");
    } catch (e:any) { setNotice(e.message || "Catalog refresh failed."); }
  }
  async function addFiles(files: FileList | null) {
    if (!files) return;
    const d = await db();
    for (const file of Array.from(files)) {
      if (!/^(image|audio|video)\\//.test(file.type)) continue;
      const dataUrl = await new Promise<string>((resolve,reject) => {
        const r = new FileReader(); r.onload=()=>resolve(String(r.result)); r.onerror=reject; r.readAsDataURL(file);
      });
      const a: Asset = { id:uid(), name:file.name, type:file.type, dataUrl, created:Date.now() };
      await d.put("assets", a);
      setAssets(old => [...old, a]);
    }
    if (studio === "Video" && Array.from(files).some(f=>f.type.startsWith("image/"))) setNotice("Image input detected — switched to image-to-video mode.");
  }
  async function removeAsset(id:string) {
    const d=await db(); await d.delete("assets",id); setAssets(old=>old.filter(a=>a.id!==id));
  }
  async function saveKey() { localStorage.setItem("ff_muapi_key",apiKey.trim()); setNotice("Key saved in this browser on this device."); }
  async function generate() {
    if (!apiKey.trim()) { setShowSettings(true); setNotice("Add your Muapi API key in Settings first."); return; }
    if (!selected?.endpoint) { setNotice("This model has no verified endpoint in the current catalog. Choose a model with a published endpoint or add a custom model."); return; }
    if (!prompt.trim() && studio !== "Lip Sync") { setNotice("Write a prompt to continue."); return; }
    if (studio === "Lip Sync" && (!assets.some(a=>a.type.startsWith("image/")) || !assets.some(a=>a.type.startsWith("audio/")))) { setNotice("Add a portrait image and an audio file."); return; }
    if (studio === "Lip Sync" && !consent) { setNotice("Confirm that you have permission to use the portrait and voice."); return; }
    setBusy(true); setNotice("Submitting generation…");
    const id=uid();
    const job:Job={id,studio,prompt,model:selected.name,status:"queued",created:Date.now()};
    const d=await db(); await d.put("jobs",job); setJobs(old=>[job,...old]);
    try {
      const payload:any={ prompt };
      if (studio === "Cinema") payload.prompt = `${prompt}. Cinematography: ${shot}, ${lens}, aperture ${aperture}, ${cameraMove}.`;
      if (studio === "Video" && assets.length) payload.image = assets.find(a=>a.type.startsWith("image/"))?.dataUrl;
      if (studio === "Lip Sync") {
        payload.image = assets.find(a=>a.type.startsWith("image/"))?.dataUrl;
        payload.audio = assets.find(a=>a.type.startsWith("audio/"))?.dataUrl;
      }
      payload.aspect_ratio=aspect;
      if (studio === "Video" || studio === "Cinema") payload.duration=Number(duration);
      const r=await fetch(`${API}/muapi/api/v1/${selected.endpoint}`,{
        method:"POST", headers:{"Content-Type":"application/json","x-muapi-key":apiKey}, body:JSON.stringify(payload)
      });
      const data=await r.json();
      if (!r.ok || !data.request_id) throw new Error(data.detail || data.error || "Provider rejected the request. Check model inputs and API key.");
      job.requestId=data.request_id; job.status="processing"; await d.put("jobs",job); setJobs(old=>old.map(j=>j.id===id?{...job}:j));
      setNotice("Generation queued. Waiting for the result…");
      for(let i=0;i<90;i++){
        await new Promise(res=>setTimeout(res,2500));
        const pr=await fetch(`${API}/muapi/api/v1/predictions/${data.request_id}/result`,{headers:{"x-muapi-key":apiKey}});
        const result=await pr.json();
        if(result.status==="completed"){
          const output=result.output?.url || result.output?.[0] || result.result?.url || result.url;
          job.status="completed"; job.output=typeof output==="string"?output:undefined;
          await d.put("jobs",job); setJobs(old=>old.map(j=>j.id===id?{...job}:j)); setNotice("Generation completed."); break;
        }
        if(["failed","cancelled"].includes(result.status)){ job.status=result.status; await d.put("jobs",job); setJobs(old=>old.map(j=>j.id===id?{...job}:j)); setNotice(result.error || "Generation failed."); break; }
      }
    } catch(e:any) { job.status="failed"; await d.put("jobs",job); setJobs(old=>old.map(j=>j.id===id?{...job}:j)); setNotice(e.message || "Generation failed."); }
    finally { setBusy(false); }
  }

  const tabs:Studio[]=["Image","Video","Lip Sync","Cinema"];
  return <div className="app-shell">
    <aside className={`sidebar ${menuOpen?"open":""}`}>
      <div className="brand"><div className="brand-mark"><Film size={19}/></div><div><b>FRAMEFORGE</b><small>CREATIVE WORKSPACE</small></div></div>
      <div className="side-label">WORKSPACE</div>
      {tabs.map(t=>{const Icon=icons[t];return <button key={t} className={`nav-item ${studio===t?"active":""}`} onClick={()=>{setStudio(t);setMenuOpen(false);}}><Icon size={18}/><span>{t} Studio</span>{studio===t&&<i/>}</button>})}
      <div className="side-label space-top">LIBRARY</div>
      <button className="nav-item" onClick={()=>setShowHistory(true)}><History size={18}/><span>Generation history</span></button>
      <button className="nav-item" onClick={()=>setShowHistory(true)}><Upload size={18}/><span>Upload library</span><em>{assets.length}</em></button>
      <div className="sidebar-bottom"><div className="connection"><span className={apiKey?"dot on":"dot"}/><div><b>{apiKey?"Key saved locally":"Not connected"}</b><small>Muapi connection</small></div></div><button className="nav-item" onClick={()=>setShowSettings(true)}><Settings size={18}/><span>Settings</span></button></div>
    </aside>

    <main className="main">
      <header className="topbar"><button className="icon-btn mobile-menu" onClick={()=>setMenuOpen(!menuOpen)}><Menu size={19}/></button><div className="crumb">Workspace <span>/</span> <b>{studio} Studio</b></div><div className="top-actions"><span className="status-pill"><span className={apiKey?"dot on":"dot"}/>{apiKey?"Connected locally":"Setup required"}</span><button className="icon-btn" onClick={()=>setShowSettings(true)}><Settings size={18}/></button><div className="avatar">F</div></div></header>

      <div className="content">
        <section className="welcome-row"><div><div className="eyebrow"><Sparkles size={13}/> CREATIVE SUITE</div><h1>{studio} <span>Studio</span></h1><p>{studio==="Image"?"Turn a thought into a frame. Generate or refine images with your favorite models.":studio==="Video"?"Bring your ideas into motion, from a text prompt or a starting frame.":studio==="Lip Sync"?"Give a portrait a voice with audio-driven animation.": "Shape every frame with intentional cinematic language."}</p></div><button className="outline-btn" onClick={()=>setShowHistory(true)}><Clock3 size={15}/> Recent work</button></section>

        <div className="studio-tabs">{tabs.map(t=>{const Icon=icons[t];return <button className={studio===t?"selected":""} key={t} onClick={()=>setStudio(t)}><Icon size={16}/>{t}</button>})}</div>
        <div className="studio-grid">
          <section className="panel editor">
            <div className="panel-head"><div><span className="step">01</span><b>Describe your creation</b></div><span className="subtle">PROMPT & INPUTS</span></div>
            <label className="field-label">YOUR PROMPT</label>
            <textarea value={prompt} onChange={e=>setPrompt(e.target.value)} placeholder={studio==="Cinema"?"A lone traveler crossing a vast desert at golden hour…":studio==="Lip Sync"?"Optional scene direction for the portrait…": "Describe what you want to create…"} rows={5}/>
            <div className="prompt-foot"><span>Be descriptive — lighting, mood, composition</span><button onClick={()=>setPrompt("A cinematic editorial portrait, soft directional light, rich natural textures, subtle film grain, art-directed composition.")}><Sparkles size={13}/> Inspire me</button></div>

            <div className="divider"/>
            <div className="section-line"><b>Media inputs</b><span>{assets.length} in library</span></div>
            <div className="dropzone" onClick={()=>fileRef.current?.click()}><input ref={fileRef} type="file" multiple accept="image/*,audio/*,video/*" hidden onChange={e=>addFiles(e.target.files)}/><div className="upload-icon"><Upload size={18}/></div><b>Drop files here or <u>browse</u></b><small>Images, audio and video · Stored on this device</small></div>
            {assets.length>0&&<div className="asset-row">{assets.map(a=><div className="asset" key={a.id}>{a.type.startsWith("image/")?<img src={a.dataUrl}/>:<div className="asset-type">{a.type.startsWith("audio/")?<AudioLines/>:<Video/>}</div>}<span title={a.name}>{a.name}</span><button onClick={()=>removeAsset(a.id)}><X size={13}/></button></div>)}</div>}
            {studio==="Video"&&<div className="mode-note"><span className="mode-dot"/><div><b>{uploadMode?"Image to video":"Text to video"} mode</b><small>{uploadMode?"Your starting image will be used as the first frame.":"Add an image to switch automatically to image-to-video."}</small></div></div>}
            {studio==="Lip Sync"&&<label className="consent"><input type="checkbox" checked={consent} onChange={e=>setConsent(e.target.checked)}/> I own or have permission to use this portrait and audio/voice.</label>}
          </section>

          <section className="panel settings-panel">
            <div className="panel-head"><div><span className="step">02</span><b>Fine-tune</b></div><SlidersHorizontal size={16} className="muted"/></div>
            <label className="field-label">MODEL</label>
            <div className="select-wrap"><select value={modelId} onChange={e=>setModelId(e.target.value)}>{(filteredModels.length?filteredModels:models).map(m=><option key={m.id} value={m.id}>{m.name}</option>)}</select><ChevronDown size={15}/></div>
            <div className="model-meta"><span className="tag">{selected?.quality || "Model"}</span><button onClick={refreshModels}><RefreshCw size={12}/> Refresh catalog</button></div>
            <div className="divider"/>
            <div className="field-grid"><div><label className="field-label">ASPECT RATIO</label><select value={aspect} onChange={e=>setAspect(e.target.value)}><option>16:9</option><option>9:16</option><option>1:1</option><option>4:5</option><option>3:2</option></select></div>
              {(studio==="Video"||studio==="Cinema")&&<div><label className="field-label">DURATION</label><select value={duration} onChange={e=>setDuration(e.target.value)}><option value="5">5 seconds</option><option value="8">8 seconds</option><option value="10">10 seconds</option><option value="15">15 seconds</option></select></div>}</div>
            {studio==="Cinema"&&<><div className="divider"/><div className="section-line"><b><Film size={14}/> Camera language</b><span className="tag violet">CINEMATIC</span></div>
              <label className="field-label">SHOT TYPE</label><select value={shot} onChange={e=>setShot(e.target.value)}>{["Extreme wide","Wide establishing","Medium close-up","Close-up","Over-the-shoulder","Macro detail"].map(v=><option>{v}</option>)}</select>
              <div className="field-grid"><div><label className="field-label">LENS</label><select value={lens} onChange={e=>setLens(e.target.value)}>{["18mm","24mm","35mm","50mm","85mm","135mm"].map(v=><option>{v}</option>)}</select></div><div><label className="field-label">APERTURE</label><select value={aperture} onChange={e=>setAperture(e.target.value)}>{["f/1.4","f/2","f/2.8","f/4","f/5.6","f/8","f/11","f/16"].map(v=><option>{v}</option>)}</select></div></div>
              <label className="field-label">CAMERA MOVEMENT</label><select value={cameraMove} onChange={e=>setCameraMove(e.target.value)}>{["Locked-off","Slow dolly","Push-in","Pull-out","Tracking shot","Crane up","Handheld subtle","Orbit"].map(v=><option>{v}</option>)}</select>
              <p className="hint">Camera controls are added to the prompt unless the selected model exposes matching native parameters.</p>
            </>}
            {multiImage&&<div className="mode-note"><CheckCircle2 size={16}/><div><b>Multi-image input supported</b><small>This model declares support for multiple references.</small></div></div>}
            <div className="generate-area"><button className="generate-btn" disabled={busy} onClick={generate}>{busy?<RefreshCw className="spin" size={17}/>:<Sparkles size={17}/>} {busy?"Generating…":"Generate"} <span>↗</span></button><small>Requests may use Muapi credits depending on the model.</small></div>
          </section>
        </div>

        <section className="results-section"><div className="results-title"><div><span className="step">03</span><b>Recent generations</b></div><button onClick={()=>setShowHistory(true)}>View all <span>↗</span></button></div>
          {jobs.length===0?<div className="empty-results"><div className="empty-icon"><Sparkles size={21}/></div><b>Your next creation starts here</b><p>Generated images and videos will appear here.</p></div>:<div className="job-grid">{jobs.slice(0,4).map(j=><div className="job-card" key={j.id}>{j.output&&<img src={j.output}/>}<div className="job-info"><b>{j.prompt||j.studio+" generation"}</b><small>{j.model} · {new Date(j.created).toLocaleString()}</small><span className={`job-status ${j.status}`}>{j.status}</span>{j.output&&<a href={j.output} download target="_blank" rel="noreferrer"><Download size={13}/> Full resolution</a>}</div></div>)}</div>}
        </section>
      </div>
    </main>

    {notice&&<div className="toast" onClick={()=>setNotice("")}><AlertCircle size={15}/>{notice}<button><X size={14}/></button></div>}
    {showSettings&&<div className="overlay" onClick={()=>setShowSettings(false)}><div className="drawer" onClick={e=>e.stopPropagation()}><div className="drawer-head"><div><span className="eyebrow">PREFERENCES</span><h2>Settings</h2></div><button className="icon-btn" onClick={()=>setShowSettings(false)}><X/></button></div><div className="setting-block"><label className="field-label">MUAPI API KEY</label><div className="key-input"><KeyRound size={16}/><input type={showKey?"text":"password"} value={apiKey} onChange={e=>setApiKey(e.target.value)} placeholder="Paste your Muapi key"/><button onClick={()=>setShowKey(!showKey)}>{showKey?"Hide":"Show"}</button></div><p className="hint">Saved only in this browser's local storage. It is sent to your self-hosted proxy only when you submit a request; the proxy does not persist it. Browser storage is not a hardware-backed secret vault.</p><button className="primary-btn" onClick={saveKey}>Save key on this device</button><button className="outline-btn full" onClick={refreshModels}><RefreshCw size={14}/> Test connection & refresh models</button><button className="text-danger" onClick={()=>{localStorage.removeItem("ff_muapi_key");setApiKey("");setNotice("Local key removed.");}}>Remove saved key</button></div><div className="setting-block"><label className="field-label">SELF-HOSTED PROXY</label><p className="hint">Current endpoint: {API}. Change VITE_PROXY_URL in your environment for your own deployment.</p></div></div></div>}
    {showHistory&&<div className="overlay" onClick={()=>setShowHistory(false)}><div className="drawer wide" onClick={e=>e.stopPropagation()}><div className="drawer-head"><div><span className="eyebrow">YOUR WORKSPACE</span><h2>Library & history</h2></div><button className="icon-btn" onClick={()=>setShowHistory(false)}><X/></button></div><h3>Uploads on this device</h3><div className="history-assets">{assets.map(a=><div className="history-asset" key={a.id}>{a.type.startsWith("image/")?<img src={a.dataUrl}/>:<div className="asset-type"><Upload/></div>}<span>{a.name}</span><button onClick={()=>removeAsset(a.id)}><Trash2 size={14}/></button></div>)}</div><h3>Generation history</h3>{jobs.length===0?<p className="hint">No generations yet.</p>:jobs.map(j=><div className="history-job" key={j.id}><div><b>{j.prompt||j.studio}</b><small>{j.model} · {new Date(j.created).toLocaleString()}</small></div><span className={`job-status ${j.status}`}>{j.status}</span>{j.output&&<a href={j.output} download target="_blank" rel="noreferrer"><Download size={14}/></a>}</div>)}</div></div>}
  </div>;
}
