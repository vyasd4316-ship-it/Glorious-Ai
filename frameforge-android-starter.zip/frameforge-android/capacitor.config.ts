import type { CapacitorConfig } from "@capacitor/cli";
const config: CapacitorConfig = {
  appId: "ai.frameforge.studio",
  appName: "FRAMEFORGE",
  webDir: "dist",
  server: { androidScheme: "https" }
};
export default config;
